# Django REST API - Blog Posts

## Setup
```
pip install -r requirements.txt
cd blog
python manage.py makemigrations helloworld
python manage.py migrate
python manage.py createsuperuser
python manage.py runserver
```
(Creates db.sqlite3. Create a second user in /admin/ to test per-user access.)

## Endpoints
| Method | URL | Description |
|---|---|---|
| POST | /api-token-auth/ | Get token (username, password) |
| GET/POST | /api/posts/ | List (5 per page) / create |
| GET/PUT/PATCH/DELETE | /api/posts/<id>/ | Retrieve / update / delete own post |

Login for browsable API: /api-auth/login/

## Query parameters
- `?search=django` (title + content)
- `?ordering=id` or `?ordering=-id`
- `?created_date=YYYY-MM-DD`, `?created_after=`, `?created_before=`
- `?page=2`

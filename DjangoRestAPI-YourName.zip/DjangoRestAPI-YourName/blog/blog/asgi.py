"""ASGI config for the blog project."""
import os

from django.core.asgi import get_asgi_application

os.environ.setdefault("DJANGO_SETTINGS_MODULE", "blog.settings")
application = get_asgi_application()

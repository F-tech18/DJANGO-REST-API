"""URL configuration for the blog project."""
from django.contrib import admin
from django.urls import include, path
from django.views.generic import RedirectView
from rest_framework.authtoken.views import obtain_auth_token
from rest_framework.routers import DefaultRouter

from helloworld.views import PostViewSet

router = DefaultRouter()
router.register(r"posts", PostViewSet, basename="post")

urlpatterns = [
    path("", RedirectView.as_view(url="/api/posts/", permanent=False)),
    path("admin/", admin.site.urls),
    path("api/", include(router.urls)),
    # Login / logout for the DRF browsable API (session authentication)
    path("api-auth/", include("rest_framework.urls")),
    # Token authentication: POST username & password -> {"token": "..."}
    path("api-token-auth/", obtain_auth_token),
]

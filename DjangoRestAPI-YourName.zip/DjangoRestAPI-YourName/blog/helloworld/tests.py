from django.contrib.auth.models import User
from rest_framework import status
from rest_framework.test import APITestCase

from .models import Post


class PostAPITests(APITestCase):
    def setUp(self):
        self.alice = User.objects.create_user("alice", password="pass12345")
        self.bob = User.objects.create_user("bob", password="pass12345")
        self.url = "/api/posts/"

    def test_login_required(self):
        self.assertEqual(self.client.get(self.url).status_code, status.HTTP_403_FORBIDDEN)

    def test_create_sets_author(self):
        self.client.force_authenticate(self.alice)
        r = self.client.post(self.url, {"title": "Hello", "content": "World"})
        self.assertEqual(r.status_code, status.HTTP_201_CREATED)
        self.assertEqual(r.data["author"], "alice")

    def test_user_sees_only_own_posts(self):
        Post.objects.create(title="A", content="a", author=self.alice)
        Post.objects.create(title="B", content="b", author=self.bob)
        self.client.force_authenticate(self.alice)
        r = self.client.get(self.url)
        self.assertEqual(r.data["count"], 1)

    def test_cannot_modify_others_post(self):
        post = Post.objects.create(title="B", content="b", author=self.bob)
        self.client.force_authenticate(self.alice)
        self.assertEqual(
            self.client.delete(f"{self.url}{post.id}/").status_code,
            status.HTTP_404_NOT_FOUND,
        )

    def test_pagination_is_five(self):
        for i in range(7):
            Post.objects.create(title=f"T{i}", content="c", author=self.alice)
        self.client.force_authenticate(self.alice)
        r = self.client.get(self.url)
        self.assertEqual(len(r.data["results"]), 5)
        self.assertEqual(r.data["count"], 7)

    def test_search_and_ordering(self):
        Post.objects.create(title="Django tips", content="x", author=self.alice)
        Post.objects.create(title="Other", content="about django", author=self.alice)
        Post.objects.create(title="Nope", content="nothing", author=self.alice)
        self.client.force_authenticate(self.alice)
        r = self.client.get(self.url, {"search": "django", "ordering": "-id"})
        self.assertEqual(r.data["count"], 2)
        self.assertGreater(r.data["results"][0]["id"], r.data["results"][1]["id"])

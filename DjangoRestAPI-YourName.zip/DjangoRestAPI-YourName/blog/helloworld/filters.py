import django_filters

from .models import Post


class PostFilter(django_filters.FilterSet):
    """Filter posts by creation date.

    ?created_date=2026-01-15      -> posts created on that day
    ?created_after=2026-01-01     -> posts created on/after that day
    ?created_before=2026-01-31    -> posts created on/before that day
    """

    created_date = django_filters.DateFilter(
        field_name="created_at", lookup_expr="date"
    )
    created_after = django_filters.DateFilter(
        field_name="created_at", lookup_expr="date__gte"
    )
    created_before = django_filters.DateFilter(
        field_name="created_at", lookup_expr="date__lte"
    )

    class Meta:
        model = Post
        fields = ["created_date", "created_after", "created_before"]

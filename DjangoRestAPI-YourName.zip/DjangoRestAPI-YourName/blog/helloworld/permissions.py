from rest_framework import permissions


class IsOwner(permissions.BasePermission):
    """Only the author of a post may view, update or delete it."""

    def has_permission(self, request, view):
        return bool(request.user and request.user.is_authenticated)

    def has_object_permission(self, request, view, obj):
        return obj.author == request.user

from rest_framework import filters, viewsets
from django_filters.rest_framework import DjangoFilterBackend

from .filters import PostFilter
from .models import Post
from .permissions import IsOwner
from .serializers import PostSerializer


class PostViewSet(viewsets.ModelViewSet):
    """CRUD API for blog posts. Users only see and modify their own posts."""

    serializer_class = PostSerializer
    permission_classes = [IsOwner]

    filter_backends = [DjangoFilterBackend, filters.SearchFilter, filters.OrderingFilter]
    filterset_class = PostFilter
    search_fields = ["title", "content"]
    ordering_fields = ["id"]
    ordering = ["id"]
    # Pagination (5 per page) is configured globally in settings.py

    def get_queryset(self):
        # Restrict every query to the logged-in user's own posts
        return Post.objects.filter(author=self.request.user)

    def perform_create(self, serializer):
        serializer.save(author=self.request.user)

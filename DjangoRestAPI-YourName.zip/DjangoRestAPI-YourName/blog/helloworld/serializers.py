from rest_framework import serializers

from .models import Post


class PostSerializer(serializers.ModelSerializer):
    # Author is set automatically from the logged-in user; it is read-only.
    author = serializers.ReadOnlyField(source="author.username")

    class Meta:
        model = Post
        fields = ["id", "title", "content", "author", "created_at", "updated_at"]
        read_only_fields = ["id", "author", "created_at", "updated_at"]
